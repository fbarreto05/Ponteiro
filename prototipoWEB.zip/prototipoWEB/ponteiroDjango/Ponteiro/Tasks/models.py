from django.db import models

def user_profile_image_path(instance, filename):
    return f'user_profiles/{instance.id}/profilePicture/{filename}'

class User(models.Model):
    picture = models.ImageField(upload_to=user_profile_image_path, blank=True, null=True, default='media/anonymous.png')
    name = models.TextField(max_length=80, default = 'name')
    id = models.TextField(max_length=20, default = 'id', primary_key=True)
    description = models.TextField(max_length=800, default = 'description')
    password = models.TextField(max_length=20, default = 'password')

    def __init__(self, defpic, defname, defid, defdescription, defpassword, *args, **kwargs):
        super(User, self).__init__(*args, **kwargs)
        self.picture = defpic
        self.name = defname
        self.id = defid
        self.description = defdescription
        self.password = defpassword

    
# Create your models here.
