from django.urls import path
from . import views

urlpatterns = [
    path('', views.title, name='title'),
    path('login/', views.login, name='login'),
    path('register/', views.register, name='register'),
    path('register/registerValidate/', views.registerValidate, name='registerValidate'),
    path('login/loginValidate/', views.loginValidate, name='loginValidate'),
    path('<str:id>/home/', views.home, name='home'),
    path('<str:id>/profile/', views.profile, name='profile'),
    path('<str:id>/userSearch/', views.userSearch, name='userSearch'),
    path('<str:id>/searchValidate/', views.searchValidate, name='searchValidate'),
    path('<str:id>/<str:searchid>_profile/', views.userSearchProfile, name='userSearchProfile'),
    path('<str:id>/logout/', views.logout, name='logout'),
] 
