from django.shortcuts import render
from .models import User
from django.http import HttpResponse
from django.shortcuts import redirect

def title(request):
    return render(request, 'titleScreen.html')

def login(request):
    error = request.GET.get('error')
    return render(request, 'loginScreen.html', {'error' : error})

def register(request):
    error = request.GET.get('error')
    return render(request, 'registerScreen.html', {'error' : error})

def registerValidate(request):
    if request.FILES.get('picture') == None:
        picture = '/anonymous.png'
    else:
        picture = request.FILES.get('picture')
    name = request.POST.get('username')
    id = request.POST.get('userid')
    description = request.POST.get('userdescription')
    password = request.POST.get('userpass')
    
    newUser = User.objects.filter(id = id)
    if len(newUser) > 0:
        return redirect('/ponteiro/register/?error=1')
    
    if id.strip() == '' or password.strip() == '' or name.strip() == '':
        return redirect('/ponteiro/register/?error=2')
    
    if any(char in id for char in [' ', '<', '>', ':', '"', '/', '\\', '|', '?', '*']):
        return redirect('/ponteiro/register/?error=3')
    
    if len(id) < 5 or len(password) < 5 or len(name) < 5:
        return redirect('/ponteiro/register/?error=4')
    if len(id) > 20 or len(password) > 20:
        return redirect('/ponteiro/register/?error=5')
    if len(name) > 80:
        return redirect('/ponteiro/register/?error=6')
    if len(description) > 800:
        return redirect('/ponteiro/register/?error=7')


    newUser = User(picture, name, id, description, password)
    newUser.save()

    return redirect('/ponteiro/register/?error=0')

def loginValidate(request):
    id = request.POST.get('userid')
    password = request.POST.get('userpass')

    if id.strip() == '' or password.strip() == '':
        return redirect('/ponteiro/login/?error=1')

    newUser = User.objects.filter(id = id).filter(password = password)
    if len(newUser) == 0:
        return redirect('/ponteiro/login/?error=2')
    
    request.session['User'] = newUser[0].id
    return redirect(f'/ponteiro/{id}/home')

def home(request, id):
    if request.session.get('User'):
        newUser = User.objects.filter(id = id)
        pictureShow = newUser[0].picture
        return render(request, 'homeScreen.html', {'picture' : pictureShow, 'id' : id})
    else:
        return redirect('/ponteiro/login/?error=3')
    
def profile(request, id):
    if request.session.get('User'):
        newUser = User.objects.filter(id = id)
        pictureShow = newUser[0].picture
        nameShow = newUser[0].name
        idShow = newUser[0].id
        descriptionShow = newUser[0].description
        passwordShow = newUser[0].password
        return render(request, 'profileScreen.html', {'picture' : pictureShow, 'name' : nameShow, 'id' : idShow, 'description' : descriptionShow, 'password' : passwordShow})
    else:
        return redirect('/ponteiro/login/?error=3')
    
def userSearch(request, id):
    if request.session.get('User'):
        newUser = User.objects.filter(id = id)
        pictureShow = newUser[0].picture
        error = request.GET.get('error')
        return render(request, 'userSearchScreen.html', {'picture' : pictureShow, 'id' : id,'error' : error})
    else:
        return redirect('/ponteiro/login/?error=3')

def searchValidate(request, id):
    if request.session.get('User'):
        userSearchId = request.POST.get('usersearchid')

        newUser = User.objects.filter(id = userSearchId).exclude(id = id)
        if len(newUser) == 0:
            return redirect(f'/ponteiro/{id}/userSearch/?error=1')
        else:
            return redirect(f'/ponteiro/{id}/{newUser[0].id}_profile')
    else:
        return redirect('/ponteiro/login/?error=3')
    
def userSearchProfile(request, id, searchid):
    if request.session.get('User'):
        yourUser = User.objects.filter(id = id)
        picture = yourUser[0].picture
        newUser = User.objects.filter(id = searchid)
        pictureShow = newUser[0].picture
        nameShow = newUser[0].name
        idShow = newUser[0].id
        descriptionShow = newUser[0].description
        return render(request, 'userSearchProfileScreen.html', {'picture' : picture, 'pictureSearched' : pictureShow, 'name' : nameShow, 'id' : id, 'idSearched' : idShow, 'description' : descriptionShow})
    else:
        return redirect('/ponteiro/login/?error=3')

def logout(request, id):
    if request.session.get('User'):
        request.session.flush()
        return redirect('/ponteiro/')
    else:
        return redirect('/ponteiro/login/?error=3')

# Create your views here.
