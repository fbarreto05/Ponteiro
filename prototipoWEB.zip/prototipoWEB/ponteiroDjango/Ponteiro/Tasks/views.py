from django.shortcuts import render
from .models import User
from django.http import HttpResponse
from django.shortcuts import redirect

def title(request):
    return render(request, 'titleScreen.html')

def login(request):
    error = request.GET.get('error')
    return render(request, 'loginScreen.html', {'error' : error})

def register(request):
    error = request.GET.get('error')
    return render(request, 'registerScreen.html', {'error' : error})

def registerValidate(request):
    login = request.POST.get('userlogin')
    password = request.POST.get('userpass')
    
    newUser = User.objects.filter(login = login)
    if len(newUser) > 0:
        return redirect('/ponteiro/register/?error=1')
    
    if login.strip() == '' or password.strip() == '':
        return redirect('/ponteiro/register/?error=2')
    
    if len(login) < 5 or len(password) < 5:
        return redirect('/ponteiro/register/?error=3')
    if len(login) > 20 or len(password) > 20:
        return redirect('/ponteiro/register/?error=4')

    newUser = User(login, password)
    newUser.save()

    return redirect('/ponteiro/register/?error=0')

def loginValidate(request):
    login = request.POST.get('userlogin')
    password = request.POST.get('userpass')

    if login.strip() == '' or password.strip() == '':
        return redirect('/ponteiro/login/?error=1')

    newUser = User.objects.filter(login = login).filter(password = password)
    if len(newUser) == 0:
        return redirect('/ponteiro/login/?error=2')
    
    request.session['User'] = newUser[0].login
    return redirect(f'/ponteiro/{login}/home')

def home(request, login):
    if request.session.get('User'):
        return render(request, 'homeScreen.html', {'login' : login})
    else:
        return redirect('/ponteiro/login/?error=3')
    
def profile(request, login):
    if request.session.get('User'):
        newUser = User.objects.filter(login = login)
        loginShow = newUser[0].login
        passwordShow = newUser[0].password
        return render(request, 'profileScreen.html', {'login' : loginShow, 'password' : passwordShow})
    else:
        return redirect('/ponteiro/login/?error=3')
    
def userSearch(request, login):
    if request.session.get('User'):
        error = request.GET.get('error')
        return render(request, 'userSearchScreen.html', {'login' : login,'error' : error})
    else:
        return redirect('/ponteiro/login/?error=3')

def searchValidate(request, login):
    if request.session.get('User'):
        userSearchLogin = request.POST.get('usersearchlogin')

        newUser = User.objects.filter(login = userSearchLogin)
        if len(newUser) == 0:
            return redirect(f'/ponteiro/{login}/userSearch/?error=1')
        else:
            return redirect(f'/ponteiro/{login}/{newUser[0].login}_profile')
    else:
        return redirect('/ponteiro/login/?error=3')
    
def userSearchProfile(request, login, searchlogin):
    if request.session.get('User'):
        return render(request, 'userSearchProfileScreen.html', {'login' : login, 'searchlogin' : searchlogin})
    else:
        return redirect('/ponteiro/login/?error=3')

def logout(request, login):
    if request.session.get('User'):
        request.session.flush()
        return redirect('/ponteiro/')
    else:
        return redirect('/ponteiro/login/?error=3')

# Create your views here.
